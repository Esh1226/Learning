package AboutUs;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;

public class AboutUsViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void initialize() {

    }
}
